MCS ↔ Citizens bridge (Studio v12)
=================================

MCS-Core soft-bridge (pas de dépendance compile-time):
  /mcs citizens attach <pack> <id> [slot]
  /mcs citizens sync

Si ElysiaCitizens / Citizens est présent, le modèle est attaché
à l'entité NPC LivingEntity avec slot head/hand_right/etc.
Les tags mcs_composite_sync permettent de re-sync à chaque tick.

Bindings: 3
