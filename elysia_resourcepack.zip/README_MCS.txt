Resource pack unifié — Minecraft Content Studio (v6/v7)
Projet: Elysia
Namespace: elysia
Minecraft: 26.1.2+
Généré: 2026-07-20T03:45:19.666Z

INSTALLATION:
1. ZIP / dossier → resourcepacks/ du client OU serveur
2. Accepter le pack en jeu (ou server.properties resource-pack=)
3. F3+T pour recharger les textures

Fichiers: 16 | Modèles: 3 | Textures: 4
Items: 1 | Blocks: 1 | Mobs: 1 | Props: 1

Items/props custom via item_model=namespace:id (1.21.4+ / 26.x)
Props: /mcs prop place <pack> <id>  ·  attach: /mcs model attach <pack> <id>
Voir mcs_pack_manifest.json pour l'inventaire complet + custom_model_data

AVERTISSEMENTS:
- block_testblock: Pas de texture — placeholder utilisé
